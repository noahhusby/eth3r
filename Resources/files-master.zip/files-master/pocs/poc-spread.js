a=new Array(0x7fffffff);[1,2,...a,...a];
